# sound-manifest.md — interativLabs · lote sonoro som-01

Revisado pelo coordenador sonoro em 07/11/2026. Os valores foram medidos por código:
- duração;
- pico real (true peak);
- volume integrado em LUFS;
- silêncio no início;
- degraus no fim;
- emendas de laço.

A escuta final de `sfx-impact-heavy-1` e `-2` e de `sfx-pop-strong` é do Will (ver "Conferir no ouvido"). Se algum voltar para geração, só a linha dele muda.

Este manifesto vai dentro de `interativlabs-som01.zip`, em `art/source/som-01/`, e é a fonte da verdade do pipeline `npm run audio`.

## Regras para a integração

**Nomes.** Os arquivos já estão no zip com o nome do ID. A coluna "Original" guarda o nome que veio da geração, só para rastreio.

**Formato de origem.** A música é Opus, cerca de 149 kbps, estéreo, 48 kHz, em contêiner `.m4a` (Suno). Os efeitos são WAV 48 kHz 24 bits mono, todos com no máximo 0,2 ms de silêncio no início.

**Formato de saída.**
- Música em AAC `.m4a`, cerca de 128 kbps, 48 kHz, estéreo, com `faststart`. Não servir o Opus original.
- Efeitos em WAV PCM 16 bits, 48 kHz, mono, com dither. Nunca AAC ou MP3, que acrescentam silêncio no início.

**Volume.** A normalização é feita no código (loudnorm mais ganho linear, pico real −1,5 dBTP), pelo alvo de cada asset:

| Classe | Alvo |
| --- | --- |
| fundo baixo (música) | −24 LUFS |
| médio | −20 LUFS |
| teto (`sfx-pop-strong`) | −18 LUFS |
| sutil | −24 LUFS |
| sutil (mínimo) | −28 LUFS |

Os efeitos de 0,3 s são curtos demais para LUFS integrado (o medidor devolve −70) e são normalizados pelo pico: sutil em −10 dBTP, sutil (mínimo) em −14 dBTP. Conferir na folha de medidas e ajustar por ouvido se algum destoar dos vizinhos.

**Variações.** Os IDs com `-1`, `-2` e `-3` são variações do mesmo som. O motor sorteia entre elas, sem repetir a anterior. Nos impactos, o motor varia o volume e o tom (±1 semitom) pela velocidade, com um limite de efeitos por instante.

**Pares.** `sfx-clock-tic` e `sfx-clock-tac` são normalizados com o mesmo ganho, calculado pelo `tic`. O `tac` é 3,6 dB mais baixo e um pouco mais grave de propósito, e essa diferença precisa sobreviver.

**Laço da música.** O laço repete só o trecho indicado (início → fim), com crossfade de potência constante de cerca de 2 s na emenda. A primeira execução toca do começo do arquivo até o fim do trecho; as seguintes repetem só o trecho. Os pontos estão no tempo do arquivo original; o script desconta o corte inicial.

**Laço da vazão.** O `sfx-vent-loop` repete o trecho indicado com crossfade de 20 ms na emenda, enquanto houver vazão. O volume acompanha a vazão, com fade de 0,1 s ao parar.

**Cortes.** Os cortes e fades das observações são aplicados uma vez, na conversão.

**Liga em.** A coluna diz quando o efeito ganha gatilho:
- **S:** na integração (Parte S da Fase 1);
- **M2, M3 e M4:** quando a peça existir, na Mecânica 2.0 (ciclo, pneumática e relojoaria). Esses efeitos entram no pipeline e no registro agora, sem gatilho.

## Música

| ID | Original → final | Formato | Duração | Laço (s) | Volume | Uso | Observações |
| --- | --- | --- | --- | --- | --- | --- | --- |
| music-bench | `music-bench - usesuno.com.m4a` → `music-bench.m4a` | Opus ~149 kbps, estéreo, 48 kHz | 158,00 s | 50,75 → 130,79 | fundo baixo | Fundo da bancada, no Montar e no Testar | Cortar 0,13 s no início: há um resíduo de decodificador a −33 dB nos primeiros 10 ms, e a música começa em 0,136 s. Cerca de 69 BPM; o laço tem 80,04 s, que dão 92 tempos inteiros. O fim natural (decaimento a partir de 151 s) não entra no laço. −15,1 LUFS; pico real 0,0 dBTP; LRA 9,5 LU. O trecho de 111 a 124 s é até cerca de 12 dB mais baixo, uma respiração dentro do laço. |

## Efeitos

Todos são WAV 48 kHz 24 bits mono. Volume e pico medidos no original.

| ID | Original | Duração | Laço | Volume | Uso | Liga em | Medidas e observações |
| --- | --- | --- | --- | --- | --- | --- | --- |
| sfx-stamp | `interativLabs_steel_screw_brass_plate.wav` | 0,50 s | não | médio | Cravar parafuso e trava | S | −21,9 LUFS; pico −3,2 dBTP. As parciais do tinido param em degrau (−43 dB) em 0,466 s: fade-out de 10 ms terminando em 0,47 s. |
| sfx-stamp-soft | `interativLabs_dowel_pin_hardwood.wav` | 0,40 s | não | sutil | Cravar eixo e pino | S | −36,3 LUFS; pico −13,0 dBTP. |
| sfx-link | `interativLabs_coil_spring_brass_pin.wav` | 0,60 s | não | sutil (mínimo) | Ligar mola, haste ou cabo | S | −39,3 LUFS; pico −20,8 dBTP. É o original mais baixo do lote. |
| sfx-lock-release | `interativLabs_brass_latch_snap_open.wav` | 0,60 s | não | médio | Soltar a trava no Testar | S | −21,0 LUFS; pico −5,1 dBTP. |
| sfx-mode | `interativLabs_wooden_drafting_ruler_paper.wav` | 0,60 s | não | sutil | Trocar entre Montar e Testar | S | −24,8 LUFS; pico −12,8 dBTP. Termina em degrau, ainda a −23 dB do pico: fade-out de 80 ms no fim. |
| sfx-cut | `interativLabs_graphite_pencil_short_stroke.wav` | 0,50 s | não | sutil | Lápis recortando ou somando | S | −25,7 LUFS; pico −13,0 dBTP. |
| sfx-ui | `interativLabs_fingertip_tap_thick_paper.wav` | 0,30 s | não | sutil (mínimo) | Abrir faixa de ferramenta ou cartão | S | Curto: normalizar pelo pico. Pico −24,0 dBTP. |
| sfx-impact-1 | `interativLabs_steel_tick_v1.wav` | 0,40 s | não | sutil (o motor varia) | Impacto de metal pequeno | S | −37,5 LUFS; pico −11,9 dBTP. |
| sfx-impact-2 | `interativLabs_steel_tick_v2.wav` | 0,40 s | não | sutil (o motor varia) | Impacto de metal pequeno | S | −35,2 LUFS; pico −10,8 dBTP. |
| sfx-impact-3 | `interativLabs_steel_tick_v3.wav` | 0,40 s | não | sutil (o motor varia) | Impacto de metal pequeno | S | −38,9 LUFS; pico −12,8 dBTP. |
| sfx-impact-heavy-1 | `interativLabs_heavy_steel_block_knock_v1.wav` | 0,60 s | não | sutil (o motor varia) | Impacto de metal pesado | S | −30,2 LUFS; pico −9,4 dBTP. Conferir no ouvido. |
| sfx-impact-heavy-2 | `interativLabs_heavy_steel_block_knock_v2.wav` | 0,60 s | não | sutil (o motor varia) | Impacto de metal pesado | S | −31,2 LUFS; pico −9,9 dBTP. Conferir no ouvido. |
| sfx-impact-wood-1 | `interativLabs_hardwood_block_knock_v1.wav` | 0,40 s | não | sutil (o motor varia) | Impacto de madeira e polímero | S | −35,9 LUFS; pico −12,0 dBTP. Ruído de fundo a −69 dB até o fim: cortar em 0,25 s com fade de 30 ms. |
| sfx-impact-wood-2 | `interativLabs_hardwood_block_knock_v2.wav` | 0,40 s | não | sutil (o motor varia) | Impacto de madeira e polímero | S | −37,2 LUFS; pico −12,6 dBTP. O mesmo corte do `-1`. |
| sfx-impact-rubber | `interativLabs_rubber_bumper_wooden_bench.wav` | 0,40 s | não | sutil (o motor varia) | Impacto de borracha | S | −35,0 LUFS; pico −13,2 dBTP. Uma só; o motor varia o tom. |
| sfx-ratchet-1 | `interativLabs_brass_ratchet_pawl_click_v1.wav` | 0,30 s | não | sutil | Lingueta caindo num dente de catraca | S | Curto: normalizar pelo pico. Pico −12,4 dBTP. Toca no lugar do impacto genérico quando o contato é de lingueta com catraca. |
| sfx-ratchet-2 | `interativLabs_brass_ratchet_pawl_click_v2.wav` | 0,30 s | não | sutil | Lingueta caindo num dente de catraca | S | Curto: normalizar pelo pico. Pico −13,6 dBTP. |
| sfx-gas | `interativLabs_brass_air_valve_puff.wav` | 0,80 s | não | médio | Câmara acendendo, carga fraca e média | S | −22,8 LUFS; pico −6,6 dBTP. |
| sfx-pop-strong | `interativLabs_brass_air_valve_strong_pop.wav` | 0,70 s | não | teto | Câmara com carga forte | S | −22,9 LUFS; pico −2,5 dBTP. É o efeito mais alto do lote depois de normalizado. Conferir no ouvido. O `…strong_pop-1.wav` recebido é cópia idêntica (mesmo MD5) e ficou fora. |
| sfx-vent-loop | `interativLabs_brass_vent_steady_hiss.wav` | 2,00 s | 0,50 → 1,50, crossfade de 20 ms | sutil (pela vazão) | Gás saindo por respiro ou porta | S | −21,0 LUFS; pico −11,0 dBTP. Estacionário: varia ±0,3 dB a cada 50 ms, com espectro constante. |
| sfx-case-drop-1 | `interativLabs_brass_tube_wooden_bench_v1.wav` | 0,80 s | não | sutil | Cápsula vazia caindo depois da ejeção | M2 | −26,9 LUFS; pico −5,1 dBTP. |
| sfx-case-drop-2 | `interativLabs_brass_tube_wooden_bench_v2.wav` | 0,80 s | não | sutil | Cápsula vazia caindo depois da ejeção | M2 | −27,9 LUFS; pico −5,7 dBTP. |
| sfx-valve | `interativLabs_brass_check_valve_close.wav` | 0,50 s | não | sutil | Válvula de retenção assentando | M3 | −25,2 LUFS; pico −3,3 dBTP. |
| sfx-clock-tic | `interativLabs_clock_escapement_single_tic.wav` | 0,30 s | não | sutil (mínimo) | Escape de relógio, batida ímpar | M4 | Curto: normalizar pelo pico; o ganho vale para o par. Pico −8,9 dBTP. |
| sfx-clock-tac | `interativLabs_clock_escapement_single_tac.wav` | 0,30 s | não | sutil (mínimo) | Escape de relógio, batida par | M4 | Mesmo ganho do `tic`. Pico −12,2 dBTP. |

Ao todo, 1 música e 25 efeitos: 20 com gatilho na Parte S e 5 registrados para a Mecânica 2.0.
